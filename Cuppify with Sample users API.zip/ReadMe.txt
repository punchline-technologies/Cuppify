Please read the LICENSE file

This source code was made by Punchline Technologies and licensed under MIT.


=================================
 

for more info visit: http://punchlinetech.com