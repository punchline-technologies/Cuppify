package b4j.example;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _application_error(RemoteObject _error,RemoteObject _stacktrace) throws Exception{
try {
		Debug.PushSubsStack("Application_Error (main) ","main",0,main.ba,main.mostCurrent,32);
if (RapidSub.canDelegate("application_error")) { return b4j.example.main.remoteMe.runUserSub(false, "main","application_error", _error, _stacktrace);}
Debug.locals.put("Error", _error);
Debug.locals.put("StackTrace", _stacktrace);
 BA.debugLineNum = 32;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 33;BA.debugLine="Return True";
Debug.ShouldStop(1);
if (true) return main.__c.getField(true,"True");
 BA.debugLineNum = 34;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable(false);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _appstart(RemoteObject _form1,RemoteObject _args) throws Exception{
try {
		Debug.PushSubsStack("AppStart (main) ","main",0,main.ba,main.mostCurrent,21);
if (RapidSub.canDelegate("appstart")) { return b4j.example.main.remoteMe.runUserSub(false, "main","appstart", _form1, _args);}
Debug.locals.put("Form1", _form1);
Debug.locals.put("Args", _args);
 BA.debugLineNum = 21;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 22;BA.debugLine="MainForm = Form1";
Debug.ShouldStop(2097152);
main._mainform = _form1;
 BA.debugLineNum = 23;BA.debugLine="MainForm.RootPane.LoadLayout(\"MainUi\") 'Load the";
Debug.ShouldStop(4194304);
main._mainform.runMethod(false,"getRootPane").runMethodAndSync(false,"LoadLayout",main.ba,(Object)(RemoteObject.createImmutable("MainUi")));
 BA.debugLineNum = 25;BA.debugLine="FullScreen(MainForm)";
Debug.ShouldStop(16777216);
_fullscreen(main._mainform);
 BA.debugLineNum = 26;BA.debugLine="MainForm.Show";
Debug.ShouldStop(33554432);
main._mainform.runVoidMethodAndSync ("Show");
 BA.debugLineNum = 29;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _button1_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button1_MousePressed (main) ","main",0,main.ba,main.mostCurrent,88);
if (RapidSub.canDelegate("button1_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button1_mousepressed", _eventdata); return;}
ResumableSub_Button1_MousePressed rsub = new ResumableSub_Button1_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button1_MousePressed extends BA.ResumableSub {
public ResumableSub_Button1_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button1_MousePressed (main) ","main",0,main.ba,main.mostCurrent,88);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 90;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(33554432);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 91;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(67108864);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 92;BA.debugLine="j.Download(UsersRestApiUrl & \"user/1\") 'where 1 i";
Debug.ShouldStop(134217728);
_j.runVoidMethod ("_download",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("user/1"))));
 BA.debugLineNum = 93;BA.debugLine="SendingRequest";
Debug.ShouldStop(268435456);
_sendingrequest();
 BA.debugLineNum = 94;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(536870912);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 95;BA.debugLine="If j.Success Then";
Debug.ShouldStop(1073741824);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 96;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(-2147483648);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 98;BA.debugLine="j.Release";
Debug.ShouldStop(2);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 100;BA.debugLine="End Sub";
Debug.ShouldStop(8);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _jobdone(RemoteObject _j) throws Exception{
}
public static void  _button2_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button2_MousePressed (main) ","main",0,main.ba,main.mostCurrent,116);
if (RapidSub.canDelegate("button2_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button2_mousepressed", _eventdata); return;}
ResumableSub_Button2_MousePressed rsub = new ResumableSub_Button2_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button2_MousePressed extends BA.ResumableSub {
public ResumableSub_Button2_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button2_MousePressed (main) ","main",0,main.ba,main.mostCurrent,116);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 118;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(2097152);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 119;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(4194304);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 120;BA.debugLine="j.Delete(UsersRestApiUrl & \"user/1\") 'where 1 is";
Debug.ShouldStop(8388608);
_j.runVoidMethod ("_delete",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("user/1"))));
 BA.debugLineNum = 121;BA.debugLine="SendingRequest";
Debug.ShouldStop(16777216);
_sendingrequest();
 BA.debugLineNum = 122;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(33554432);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 123;BA.debugLine="If j.Success Then";
Debug.ShouldStop(67108864);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 124;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(134217728);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 126;BA.debugLine="j.Release";
Debug.ShouldStop(536870912);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 128;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _button3_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button3_MousePressed (main) ","main",0,main.ba,main.mostCurrent,130);
if (RapidSub.canDelegate("button3_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button3_mousepressed", _eventdata); return;}
ResumableSub_Button3_MousePressed rsub = new ResumableSub_Button3_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button3_MousePressed extends BA.ResumableSub {
public ResumableSub_Button3_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _data = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button3_MousePressed (main) ","main",0,main.ba,main.mostCurrent,130);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 133;BA.debugLine="Dim data As Map";
Debug.ShouldStop(16);
_data = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("data", _data);
 BA.debugLineNum = 134;BA.debugLine="data.Initialize";
Debug.ShouldStop(32);
_data.runVoidMethod ("Initialize");
 BA.debugLineNum = 136;BA.debugLine="data.Put(\"name\", \"Frost Codes_\" & Rnd(12,99999))";
Debug.ShouldStop(128);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("name"))),(Object)((RemoteObject.concat(RemoteObject.createImmutable("Frost Codes_"),parent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 12)),(Object)(BA.numberCast(int.class, 99999)))))));
 BA.debugLineNum = 137;BA.debugLine="data.Put(\"gender\", \"Male\")";
Debug.ShouldStop(256);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("gender"))),(Object)((RemoteObject.createImmutable("Male"))));
 BA.debugLineNum = 139;BA.debugLine="Sleep(0) 'For improved Randomness";
Debug.ShouldStop(1024);
parent.__c.runVoidMethod ("Sleep",main.ba,anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this),BA.numberCast(int.class, 0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
 BA.debugLineNum = 141;BA.debugLine="data.Put(\"email\", \"frost_\" &  Rnd(12,99999) & \"@g";
Debug.ShouldStop(4096);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("email"))),(Object)((RemoteObject.concat(RemoteObject.createImmutable("frost_"),parent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 12)),(Object)(BA.numberCast(int.class, 99999))),RemoteObject.createImmutable("@gmail.com")))));
 BA.debugLineNum = 142;BA.debugLine="data.Put(\"company\", \"Punchline Technologies\")";
Debug.ShouldStop(8192);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("company"))),(Object)((RemoteObject.createImmutable("Punchline Technologies"))));
 BA.debugLineNum = 144;BA.debugLine="data.Put(\"occupation\", \"Cloud and Backend Enginee";
Debug.ShouldStop(32768);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("occupation"))),(Object)((RemoteObject.createImmutable("Cloud and Backend Engineer"))));
 BA.debugLineNum = 146;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(131072);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 147;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(262144);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 148;BA.debugLine="j.PostString(UsersRestApiUrl & \"user/1\", Map2Http";
Debug.ShouldStop(524288);
_j.runVoidMethod ("_poststring",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("user/1"))),(Object)(_map2httprequeststring(_data)));
 BA.debugLineNum = 149;BA.debugLine="SendingRequest";
Debug.ShouldStop(1048576);
_sendingrequest();
 BA.debugLineNum = 150;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(2097152);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 6;
return;
case 6:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 151;BA.debugLine="If j.Success Then";
Debug.ShouldStop(4194304);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 152;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(8388608);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 154;BA.debugLine="j.Release";
Debug.ShouldStop(33554432);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 156;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _button4_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button4_MousePressed (main) ","main",0,main.ba,main.mostCurrent,158);
if (RapidSub.canDelegate("button4_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button4_mousepressed", _eventdata); return;}
ResumableSub_Button4_MousePressed rsub = new ResumableSub_Button4_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button4_MousePressed extends BA.ResumableSub {
public ResumableSub_Button4_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _data = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button4_MousePressed (main) ","main",0,main.ba,main.mostCurrent,158);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 161;BA.debugLine="Dim data As Map";
Debug.ShouldStop(1);
_data = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("data", _data);
 BA.debugLineNum = 162;BA.debugLine="data.Initialize";
Debug.ShouldStop(2);
_data.runVoidMethod ("Initialize");
 BA.debugLineNum = 164;BA.debugLine="data.Put(\"name\", \"New Frost Codes_\" & Rnd(12,9999";
Debug.ShouldStop(8);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("name"))),(Object)((RemoteObject.concat(RemoteObject.createImmutable("New Frost Codes_"),parent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 12)),(Object)(BA.numberCast(int.class, 99999)))))));
 BA.debugLineNum = 165;BA.debugLine="data.Put(\"gender\", \"Female\")";
Debug.ShouldStop(16);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("gender"))),(Object)((RemoteObject.createImmutable("Female"))));
 BA.debugLineNum = 167;BA.debugLine="Sleep(0) 'For improved Randomness";
Debug.ShouldStop(64);
parent.__c.runVoidMethod ("Sleep",main.ba,anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this),BA.numberCast(int.class, 0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
 BA.debugLineNum = 169;BA.debugLine="data.Put(\"email\", \"frost_\" &  Rnd(12,99999) & \"@g";
Debug.ShouldStop(256);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("email"))),(Object)((RemoteObject.concat(RemoteObject.createImmutable("frost_"),parent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 12)),(Object)(BA.numberCast(int.class, 99999))),RemoteObject.createImmutable("@gmail.com")))));
 BA.debugLineNum = 170;BA.debugLine="data.Put(\"company\", \"Punchline Technologies Afric";
Debug.ShouldStop(512);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("company"))),(Object)((RemoteObject.createImmutable("Punchline Technologies Africa"))));
 BA.debugLineNum = 172;BA.debugLine="data.Put(\"occupation\", \"Software and Backend Engi";
Debug.ShouldStop(2048);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("occupation"))),(Object)((RemoteObject.createImmutable("Software and Backend Engineer"))));
 BA.debugLineNum = 174;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(8192);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 175;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(16384);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 176;BA.debugLine="j.PutString(UsersRestApiUrl & \"user/1\", Map2HttpR";
Debug.ShouldStop(32768);
_j.runVoidMethod ("_putstring",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("user/1"))),(Object)(_map2httprequeststring(_data)));
 BA.debugLineNum = 177;BA.debugLine="SendingRequest";
Debug.ShouldStop(65536);
_sendingrequest();
 BA.debugLineNum = 178;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(131072);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 6;
return;
case 6:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 179;BA.debugLine="If j.Success Then";
Debug.ShouldStop(262144);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 180;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(524288);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 182;BA.debugLine="j.Release";
Debug.ShouldStop(2097152);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 184;BA.debugLine="End Sub";
Debug.ShouldStop(8388608);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _button5_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button5_MousePressed (main) ","main",0,main.ba,main.mostCurrent,74);
if (RapidSub.canDelegate("button5_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button5_mousepressed", _eventdata); return;}
ResumableSub_Button5_MousePressed rsub = new ResumableSub_Button5_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button5_MousePressed extends BA.ResumableSub {
public ResumableSub_Button5_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button5_MousePressed (main) ","main",0,main.ba,main.mostCurrent,74);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 76;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(2048);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 77;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(4096);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 78;BA.debugLine="j.Download(UsersRestApiUrl & \"users\") 'gets all u";
Debug.ShouldStop(8192);
_j.runVoidMethod ("_download",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("users"))));
 BA.debugLineNum = 79;BA.debugLine="SendingRequest";
Debug.ShouldStop(16384);
_sendingrequest();
 BA.debugLineNum = 80;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(32768);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 81;BA.debugLine="If j.Success Then";
Debug.ShouldStop(65536);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 82;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(131072);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 84;BA.debugLine="j.Release";
Debug.ShouldStop(524288);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 86;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _button6_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button6_MousePressed (main) ","main",0,main.ba,main.mostCurrent,102);
if (RapidSub.canDelegate("button6_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button6_mousepressed", _eventdata); return;}
ResumableSub_Button6_MousePressed rsub = new ResumableSub_Button6_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button6_MousePressed extends BA.ResumableSub {
public ResumableSub_Button6_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button6_MousePressed (main) ","main",0,main.ba,main.mostCurrent,102);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 104;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(128);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 105;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(256);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 106;BA.debugLine="j.Download(UsersRestApiUrl & \"users?page=2&limit=";
Debug.ShouldStop(512);
_j.runVoidMethod ("_download",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("users?page=2&limit=10"))));
 BA.debugLineNum = 107;BA.debugLine="SendingRequest";
Debug.ShouldStop(1024);
_sendingrequest();
 BA.debugLineNum = 108;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(2048);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 109;BA.debugLine="If j.Success Then";
Debug.ShouldStop(4096);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 110;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(8192);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 112;BA.debugLine="j.Release";
Debug.ShouldStop(32768);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 114;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _button7_mousepressed(RemoteObject _eventdata) throws Exception{
try {
		Debug.PushSubsStack("Button7_MousePressed (main) ","main",0,main.ba,main.mostCurrent,186);
if (RapidSub.canDelegate("button7_mousepressed")) { b4j.example.main.remoteMe.runUserSub(false, "main","button7_mousepressed", _eventdata); return;}
ResumableSub_Button7_MousePressed rsub = new ResumableSub_Button7_MousePressed(null,_eventdata);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Button7_MousePressed extends BA.ResumableSub {
public ResumableSub_Button7_MousePressed(b4j.example.main parent,RemoteObject _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
b4j.example.main parent;
RemoteObject _eventdata;
RemoteObject _data = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
RemoteObject _j = RemoteObject.declareNull("b4j.example.httpjob");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Button7_MousePressed (main) ","main",0,main.ba,main.mostCurrent,186);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("EventData", _eventdata);
 BA.debugLineNum = 188;BA.debugLine="Dim data As Map";
Debug.ShouldStop(134217728);
_data = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("data", _data);
 BA.debugLineNum = 189;BA.debugLine="data.Initialize";
Debug.ShouldStop(268435456);
_data.runVoidMethod ("Initialize");
 BA.debugLineNum = 195;BA.debugLine="data.Put(\"occupation\", \"Web developer and Ui/Ux D";
Debug.ShouldStop(4);
_data.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("occupation"))),(Object)((RemoteObject.createImmutable("Web developer and Ui/Ux Designer"))));
 BA.debugLineNum = 197;BA.debugLine="Dim j As HttpJob";
Debug.ShouldStop(16);
_j = RemoteObject.createNew ("b4j.example.httpjob");Debug.locals.put("j", _j);
 BA.debugLineNum = 198;BA.debugLine="j.Initialize(\"\", Me)";
Debug.ShouldStop(32);
_j.runVoidMethod ("_initialize",main.ba,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 205;BA.debugLine="j.PostString(UsersRestApiUrl & \"user/1\", Map2Http";
Debug.ShouldStop(4096);
_j.runVoidMethod ("_poststring",(Object)(RemoteObject.concat(parent._usersrestapiurl,RemoteObject.createImmutable("user/1"))),(Object)(RemoteObject.concat(_map2httprequeststring(_data),RemoteObject.createImmutable("&_method=PATCH"))));
 BA.debugLineNum = 207;BA.debugLine="SendingRequest";
Debug.ShouldStop(16384);
_sendingrequest();
 BA.debugLineNum = 208;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
Debug.ShouldStop(32768);
parent.__c.runVoidMethod ("WaitFor","jobdone", main.ba, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this), (_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("j", _j);
;
 BA.debugLineNum = 209;BA.debugLine="If j.Success Then";
Debug.ShouldStop(65536);
if (true) break;

case 1:
//if
this.state = 4;
if (_j.getField(true,"_success").<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 210;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
Debug.ShouldStop(131072);
_logresponse(_j.runMethod(true,"_getstring"));
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 212;BA.debugLine="j.Release";
Debug.ShouldStop(524288);
_j.runVoidMethod ("_release");
 BA.debugLineNum = 214;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static RemoteObject  _fullscreen(RemoteObject _frm) throws Exception{
try {
		Debug.PushSubsStack("FullScreen (main) ","main",0,main.ba,main.mostCurrent,36);
if (RapidSub.canDelegate("fullscreen")) { return b4j.example.main.remoteMe.runUserSub(false, "main","fullscreen", _frm);}
RemoteObject _joform = RemoteObject.declareNull("anywheresoftware.b4j.object.JavaObject");
RemoteObject _jostage = RemoteObject.declareNull("anywheresoftware.b4j.object.JavaObject");
Debug.locals.put("Frm", _frm);
 BA.debugLineNum = 36;BA.debugLine="Sub FullScreen(Frm As Form)";
Debug.ShouldStop(8);
 BA.debugLineNum = 37;BA.debugLine="Dim joForm As JavaObject = Frm";
Debug.ShouldStop(16);
_joform = RemoteObject.createNew ("anywheresoftware.b4j.object.JavaObject");
_joform.setObject(_frm);Debug.locals.put("joForm", _joform);
 BA.debugLineNum = 38;BA.debugLine="Dim joStage As JavaObject = joForm.GetField(\"stag";
Debug.ShouldStop(32);
_jostage = RemoteObject.createNew ("anywheresoftware.b4j.object.JavaObject");
_jostage.setObject(_joform.runMethod(false,"GetField",(Object)(RemoteObject.createImmutable("stage"))));Debug.locals.put("joStage", _jostage);
 BA.debugLineNum = 39;BA.debugLine="joStage.RunMethod(\"setMaximized\", Array(True))";
Debug.ShouldStop(64);
_jostage.runVoidMethod ("RunMethod",(Object)(BA.ObjectToString("setMaximized")),(Object)(RemoteObject.createNewArray("Object",new int[] {1},new Object[] {(main.__c.getField(true,"True"))})));
 BA.debugLineNum = 40;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _logresponse(RemoteObject _response) throws Exception{
try {
		Debug.PushSubsStack("LogResponse (main) ","main",0,main.ba,main.mostCurrent,42);
if (RapidSub.canDelegate("logresponse")) { return b4j.example.main.remoteMe.runUserSub(false, "main","logresponse", _response);}
Debug.locals.put("response", _response);
 BA.debugLineNum = 42;BA.debugLine="Public Sub LogResponse(response As String)";
Debug.ShouldStop(512);
 BA.debugLineNum = 44;BA.debugLine="TextArea1.Text = response";
Debug.ShouldStop(2048);
main._textarea1.runMethod(true,"setText",_response);
 BA.debugLineNum = 45;BA.debugLine="Label1.Text = \"Status: Response ready!\"";
Debug.ShouldStop(4096);
main._label1.runMethod(true,"setText",BA.ObjectToString("Status: Response ready!"));
 BA.debugLineNum = 46;BA.debugLine="Label1.TextColor = fx.Colors.RGB(0,148,56)";
Debug.ShouldStop(8192);
main._label1.runMethod(false,"setTextColor",(main._fx.getField(false,"Colors").runMethod(false,"RGB",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 148)),(Object)(BA.numberCast(int.class, 56)))));
 BA.debugLineNum = 48;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _map2httprequeststring(RemoteObject _map) throws Exception{
try {
		Debug.PushSubsStack("Map2HttpRequestString (main) ","main",0,main.ba,main.mostCurrent,59);
if (RapidSub.canDelegate("map2httprequeststring")) { return b4j.example.main.remoteMe.runUserSub(false, "main","map2httprequeststring", _map);}
RemoteObject _result = RemoteObject.declareNull("anywheresoftware.b4a.keywords.StringBuilderWrapper");
int _i = 0;
Debug.locals.put("Map", _map);
 BA.debugLineNum = 59;BA.debugLine="Public Sub Map2HttpRequestString(Map As Map) As St";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 61;BA.debugLine="Dim result As StringBuilder";
Debug.ShouldStop(268435456);
_result = RemoteObject.createNew ("anywheresoftware.b4a.keywords.StringBuilderWrapper");Debug.locals.put("result", _result);
 BA.debugLineNum = 62;BA.debugLine="result.Initialize";
Debug.ShouldStop(536870912);
_result.runVoidMethod ("Initialize");
 BA.debugLineNum = 64;BA.debugLine="For i = 0 To Map.Size - 1";
Debug.ShouldStop(-2147483648);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {_map.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 66;BA.debugLine="result.Append(Map.GetKeyAt(i) & \"=\" & Map.GetVal";
Debug.ShouldStop(2);
_result.runVoidMethod ("Append",(Object)(RemoteObject.concat(_map.runMethod(false,"GetKeyAt",(Object)(BA.numberCast(int.class, _i))),RemoteObject.createImmutable("="),_map.runMethod(false,"GetValueAt",(Object)(BA.numberCast(int.class, _i))),RemoteObject.createImmutable("&"))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 70;BA.debugLine="Return result.ToString.SubString2(0, result.ToStr";
Debug.ShouldStop(32);
if (true) return _result.runMethod(true,"ToString").runMethod(true,"substring",(Object)(BA.numberCast(int.class, 0)),(Object)(RemoteObject.solve(new RemoteObject[] {_result.runMethod(true,"ToString").runMethod(true,"length"),RemoteObject.createImmutable(1)}, "-",1, 1)));
 BA.debugLineNum = 72;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("b4j.example.main");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
main._fx = RemoteObject.createNew ("anywheresoftware.b4j.objects.JFX");
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
main._mainform = RemoteObject.createNew ("anywheresoftware.b4j.objects.Form");
 //BA.debugLineNum = 9;BA.debugLine="Private Button1 As Button";
main._button1 = RemoteObject.createNew ("anywheresoftware.b4j.objects.ButtonWrapper");
 //BA.debugLineNum = 10;BA.debugLine="Private Button2 As Button";
main._button2 = RemoteObject.createNew ("anywheresoftware.b4j.objects.ButtonWrapper");
 //BA.debugLineNum = 11;BA.debugLine="Private Button3 As Button";
main._button3 = RemoteObject.createNew ("anywheresoftware.b4j.objects.ButtonWrapper");
 //BA.debugLineNum = 12;BA.debugLine="Private Button4 As Button";
main._button4 = RemoteObject.createNew ("anywheresoftware.b4j.objects.ButtonWrapper");
 //BA.debugLineNum = 13;BA.debugLine="Private TextArea1 As TextArea";
main._textarea1 = RemoteObject.createNew ("anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper");
 //BA.debugLineNum = 14;BA.debugLine="Private Label1 As Label";
main._label1 = RemoteObject.createNew ("anywheresoftware.b4j.objects.LabelWrapper");
 //BA.debugLineNum = 16;BA.debugLine="Private RestApiUrl As String = \"http://localhost:";
main._restapiurl = BA.ObjectToString("http://localhost:8888/");
 //BA.debugLineNum = 17;BA.debugLine="Private UsersRestApiUrl As String = RestApiUrl &";
main._usersrestapiurl = RemoteObject.concat(main._restapiurl,RemoteObject.createImmutable("users/"));
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _sendingrequest() throws Exception{
try {
		Debug.PushSubsStack("SendingRequest (main) ","main",0,main.ba,main.mostCurrent,50);
if (RapidSub.canDelegate("sendingrequest")) { return b4j.example.main.remoteMe.runUserSub(false, "main","sendingrequest");}
 BA.debugLineNum = 50;BA.debugLine="Public Sub SendingRequest";
Debug.ShouldStop(131072);
 BA.debugLineNum = 52;BA.debugLine="Label1.Text = \"Status: Sending Request!\"";
Debug.ShouldStop(524288);
main._label1.runMethod(true,"setText",BA.ObjectToString("Status: Sending Request!"));
 BA.debugLineNum = 53;BA.debugLine="Label1.TextColor = fx.Colors.Magenta";
Debug.ShouldStop(1048576);
main._label1.runMethod(false,"setTextColor",main._fx.getField(false,"Colors").getField(false,"Magenta"));
 BA.debugLineNum = 55;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}