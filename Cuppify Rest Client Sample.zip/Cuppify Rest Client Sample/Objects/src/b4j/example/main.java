package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.debug.*;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.ShellBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			anywheresoftware.b4a.ShellBA.delegateBA = new anywheresoftware.b4j.objects.FxBA("b4j.example", null, null);
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }


private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button1 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button2 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button3 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button4 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper _textarea1 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _label1 = null;
public static String _restapiurl = "";
public static String _usersrestapiurl = "";
public static b4j.example.httputils2service _httputils2service = null;
public static boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "application_error"))
	 {return ((Boolean) Debug.delegate(ba, "application_error", new Object[] {_error,_stacktrace}));}
RDebugUtils.currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
RDebugUtils.currentLine=131073;
 //BA.debugLineNum = 131073;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
RDebugUtils.currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="End Sub";
return false;
}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "appstart"))
	 {return ((String) Debug.delegate(ba, "appstart", new Object[] {_form1,_args}));}
RDebugUtils.currentLine=65536;
 //BA.debugLineNum = 65536;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
RDebugUtils.currentLine=65537;
 //BA.debugLineNum = 65537;BA.debugLine="MainForm = Form1";
_mainform = _form1;
RDebugUtils.currentLine=65538;
 //BA.debugLineNum = 65538;BA.debugLine="MainForm.RootPane.LoadLayout(\"MainUi\") 'Load the";
_mainform.getRootPane().LoadLayout(ba,"MainUi");
RDebugUtils.currentLine=65540;
 //BA.debugLineNum = 65540;BA.debugLine="FullScreen(MainForm)";
_fullscreen(_mainform);
RDebugUtils.currentLine=65541;
 //BA.debugLineNum = 65541;BA.debugLine="MainForm.Show";
_mainform.Show();
RDebugUtils.currentLine=65544;
 //BA.debugLineNum = 65544;BA.debugLine="End Sub";
return "";
}
public static String  _fullscreen(anywheresoftware.b4j.objects.Form _frm) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "fullscreen"))
	 {return ((String) Debug.delegate(ba, "fullscreen", new Object[] {_frm}));}
anywheresoftware.b4j.object.JavaObject _joform = null;
anywheresoftware.b4j.object.JavaObject _jostage = null;
RDebugUtils.currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Sub FullScreen(Frm As Form)";
RDebugUtils.currentLine=196609;
 //BA.debugLineNum = 196609;BA.debugLine="Dim joForm As JavaObject = Frm";
_joform = new anywheresoftware.b4j.object.JavaObject();
_joform.setObject((java.lang.Object)(_frm));
RDebugUtils.currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="Dim joStage As JavaObject = joForm.GetField(\"stag";
_jostage = new anywheresoftware.b4j.object.JavaObject();
_jostage.setObject((java.lang.Object)(_joform.GetField("stage")));
RDebugUtils.currentLine=196611;
 //BA.debugLineNum = 196611;BA.debugLine="joStage.RunMethod(\"setMaximized\", Array(True))";
_jostage.RunMethod("setMaximized",new Object[]{(Object)(anywheresoftware.b4a.keywords.Common.True)});
RDebugUtils.currentLine=196612;
 //BA.debugLineNum = 196612;BA.debugLine="End Sub";
return "";
}
public static void  _button1_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button1_mousepressed"))
	 {Debug.delegate(ba, "button1_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button1_MousePressed rsub = new ResumableSub_Button1_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button1_MousePressed extends BA.ResumableSub {
public ResumableSub_Button1_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=524290;
 //BA.debugLineNum = 524290;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=524291;
 //BA.debugLineNum = 524291;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=524292;
 //BA.debugLineNum = 524292;BA.debugLine="j.Download(UsersRestApiUrl & \"user/1\") 'where 1 i";
_j._download(parent._usersrestapiurl+"user/1");
RDebugUtils.currentLine=524293;
 //BA.debugLineNum = 524293;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=524294;
 //BA.debugLineNum = 524294;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button1_mousepressed"), (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=524295;
 //BA.debugLineNum = 524295;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=524296;
 //BA.debugLineNum = 524296;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=524298;
 //BA.debugLineNum = 524298;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=524300;
 //BA.debugLineNum = 524300;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _sendingrequest() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "sendingrequest"))
	 {return ((String) Debug.delegate(ba, "sendingrequest", null));}
RDebugUtils.currentLine=327680;
 //BA.debugLineNum = 327680;BA.debugLine="Public Sub SendingRequest";
RDebugUtils.currentLine=327682;
 //BA.debugLineNum = 327682;BA.debugLine="Label1.Text = \"Status: Sending Request!\"";
_label1.setText("Status: Sending Request!");
RDebugUtils.currentLine=327683;
 //BA.debugLineNum = 327683;BA.debugLine="Label1.TextColor = fx.Colors.Magenta";
_label1.setTextColor(_fx.Colors.Magenta);
RDebugUtils.currentLine=327685;
 //BA.debugLineNum = 327685;BA.debugLine="End Sub";
return "";
}
public static String  _logresponse(String _response) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "logresponse"))
	 {return ((String) Debug.delegate(ba, "logresponse", new Object[] {_response}));}
RDebugUtils.currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Public Sub LogResponse(response As String)";
RDebugUtils.currentLine=262146;
 //BA.debugLineNum = 262146;BA.debugLine="TextArea1.Text = response";
_textarea1.setText(_response);
RDebugUtils.currentLine=262147;
 //BA.debugLineNum = 262147;BA.debugLine="Label1.Text = \"Status: Response ready!\"";
_label1.setText("Status: Response ready!");
RDebugUtils.currentLine=262148;
 //BA.debugLineNum = 262148;BA.debugLine="Label1.TextColor = fx.Colors.RGB(0,148,56)";
_label1.setTextColor((javafx.scene.paint.Paint)(_fx.Colors.RGB((int) (0),(int) (148),(int) (56))));
RDebugUtils.currentLine=262150;
 //BA.debugLineNum = 262150;BA.debugLine="End Sub";
return "";
}
public static void  _button2_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button2_mousepressed"))
	 {Debug.delegate(ba, "button2_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button2_MousePressed rsub = new ResumableSub_Button2_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button2_MousePressed extends BA.ResumableSub {
public ResumableSub_Button2_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=655362;
 //BA.debugLineNum = 655362;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=655363;
 //BA.debugLineNum = 655363;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=655364;
 //BA.debugLineNum = 655364;BA.debugLine="j.Delete(UsersRestApiUrl & \"user/1\") 'where 1 is";
_j._delete(parent._usersrestapiurl+"user/1");
RDebugUtils.currentLine=655365;
 //BA.debugLineNum = 655365;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=655366;
 //BA.debugLineNum = 655366;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button2_mousepressed"), (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=655367;
 //BA.debugLineNum = 655367;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=655368;
 //BA.debugLineNum = 655368;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=655370;
 //BA.debugLineNum = 655370;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=655372;
 //BA.debugLineNum = 655372;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _button3_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button3_mousepressed"))
	 {Debug.delegate(ba, "button3_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button3_MousePressed rsub = new ResumableSub_Button3_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button3_MousePressed extends BA.ResumableSub {
public ResumableSub_Button3_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
anywheresoftware.b4a.objects.collections.Map _data = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=720899;
 //BA.debugLineNum = 720899;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=720900;
 //BA.debugLineNum = 720900;BA.debugLine="data.Initialize";
_data.Initialize();
RDebugUtils.currentLine=720902;
 //BA.debugLineNum = 720902;BA.debugLine="data.Put(\"name\", \"Frost Codes_\" & Rnd(12,99999))";
_data.Put((Object)("name"),(Object)("Frost Codes_"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (12),(int) (99999)))));
RDebugUtils.currentLine=720903;
 //BA.debugLineNum = 720903;BA.debugLine="data.Put(\"gender\", \"Male\")";
_data.Put((Object)("gender"),(Object)("Male"));
RDebugUtils.currentLine=720905;
 //BA.debugLineNum = 720905;BA.debugLine="Sleep(0) 'For improved Randomness";
anywheresoftware.b4a.keywords.Common.Sleep(ba,new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button3_mousepressed"),(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
RDebugUtils.currentLine=720907;
 //BA.debugLineNum = 720907;BA.debugLine="data.Put(\"email\", \"frost_\" &  Rnd(12,99999) & \"@g";
_data.Put((Object)("email"),(Object)("frost_"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (12),(int) (99999)))+"@gmail.com"));
RDebugUtils.currentLine=720908;
 //BA.debugLineNum = 720908;BA.debugLine="data.Put(\"company\", \"Punchline Technologies\")";
_data.Put((Object)("company"),(Object)("Punchline Technologies"));
RDebugUtils.currentLine=720910;
 //BA.debugLineNum = 720910;BA.debugLine="data.Put(\"occupation\", \"Cloud and Backend Enginee";
_data.Put((Object)("occupation"),(Object)("Cloud and Backend Engineer"));
RDebugUtils.currentLine=720912;
 //BA.debugLineNum = 720912;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=720913;
 //BA.debugLineNum = 720913;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=720914;
 //BA.debugLineNum = 720914;BA.debugLine="j.PostString(UsersRestApiUrl & \"user/1\", Map2Http";
_j._poststring(parent._usersrestapiurl+"user/1",_map2httprequeststring(_data));
RDebugUtils.currentLine=720915;
 //BA.debugLineNum = 720915;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=720916;
 //BA.debugLineNum = 720916;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button3_mousepressed"), (Object)(_j));
this.state = 6;
return;
case 6:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=720917;
 //BA.debugLineNum = 720917;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=720918;
 //BA.debugLineNum = 720918;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=720920;
 //BA.debugLineNum = 720920;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=720922;
 //BA.debugLineNum = 720922;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _map2httprequeststring(anywheresoftware.b4a.objects.collections.Map _map) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "map2httprequeststring"))
	 {return ((String) Debug.delegate(ba, "map2httprequeststring", new Object[] {_map}));}
anywheresoftware.b4a.keywords.StringBuilderWrapper _result = null;
int _i = 0;
RDebugUtils.currentLine=393216;
 //BA.debugLineNum = 393216;BA.debugLine="Public Sub Map2HttpRequestString(Map As Map) As St";
RDebugUtils.currentLine=393218;
 //BA.debugLineNum = 393218;BA.debugLine="Dim result As StringBuilder";
_result = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
RDebugUtils.currentLine=393219;
 //BA.debugLineNum = 393219;BA.debugLine="result.Initialize";
_result.Initialize();
RDebugUtils.currentLine=393221;
 //BA.debugLineNum = 393221;BA.debugLine="For i = 0 To Map.Size - 1";
{
final int step3 = 1;
final int limit3 = (int) (_map.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
RDebugUtils.currentLine=393223;
 //BA.debugLineNum = 393223;BA.debugLine="result.Append(Map.GetKeyAt(i) & \"=\" & Map.GetVal";
_result.Append(BA.ObjectToString(_map.GetKeyAt(_i))+"="+BA.ObjectToString(_map.GetValueAt(_i))+"&");
 }
};
RDebugUtils.currentLine=393227;
 //BA.debugLineNum = 393227;BA.debugLine="Return result.ToString.SubString2(0, result.ToStr";
if (true) return _result.ToString().substring((int) (0),(int) (_result.ToString().length()-1));
RDebugUtils.currentLine=393229;
 //BA.debugLineNum = 393229;BA.debugLine="End Sub";
return "";
}
public static void  _button4_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button4_mousepressed"))
	 {Debug.delegate(ba, "button4_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button4_MousePressed rsub = new ResumableSub_Button4_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button4_MousePressed extends BA.ResumableSub {
public ResumableSub_Button4_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
anywheresoftware.b4a.objects.collections.Map _data = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=786435;
 //BA.debugLineNum = 786435;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=786436;
 //BA.debugLineNum = 786436;BA.debugLine="data.Initialize";
_data.Initialize();
RDebugUtils.currentLine=786438;
 //BA.debugLineNum = 786438;BA.debugLine="data.Put(\"name\", \"New Frost Codes_\" & Rnd(12,9999";
_data.Put((Object)("name"),(Object)("New Frost Codes_"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (12),(int) (99999)))));
RDebugUtils.currentLine=786439;
 //BA.debugLineNum = 786439;BA.debugLine="data.Put(\"gender\", \"Female\")";
_data.Put((Object)("gender"),(Object)("Female"));
RDebugUtils.currentLine=786441;
 //BA.debugLineNum = 786441;BA.debugLine="Sleep(0) 'For improved Randomness";
anywheresoftware.b4a.keywords.Common.Sleep(ba,new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button4_mousepressed"),(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
RDebugUtils.currentLine=786443;
 //BA.debugLineNum = 786443;BA.debugLine="data.Put(\"email\", \"frost_\" &  Rnd(12,99999) & \"@g";
_data.Put((Object)("email"),(Object)("frost_"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (12),(int) (99999)))+"@gmail.com"));
RDebugUtils.currentLine=786444;
 //BA.debugLineNum = 786444;BA.debugLine="data.Put(\"company\", \"Punchline Technologies Afric";
_data.Put((Object)("company"),(Object)("Punchline Technologies Africa"));
RDebugUtils.currentLine=786446;
 //BA.debugLineNum = 786446;BA.debugLine="data.Put(\"occupation\", \"Software and Backend Engi";
_data.Put((Object)("occupation"),(Object)("Software and Backend Engineer"));
RDebugUtils.currentLine=786448;
 //BA.debugLineNum = 786448;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=786449;
 //BA.debugLineNum = 786449;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=786450;
 //BA.debugLineNum = 786450;BA.debugLine="j.PutString(UsersRestApiUrl & \"user/1\", Map2HttpR";
_j._putstring(parent._usersrestapiurl+"user/1",_map2httprequeststring(_data));
RDebugUtils.currentLine=786451;
 //BA.debugLineNum = 786451;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=786452;
 //BA.debugLineNum = 786452;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button4_mousepressed"), (Object)(_j));
this.state = 6;
return;
case 6:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=786453;
 //BA.debugLineNum = 786453;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=786454;
 //BA.debugLineNum = 786454;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=786456;
 //BA.debugLineNum = 786456;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=786458;
 //BA.debugLineNum = 786458;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _button5_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button5_mousepressed"))
	 {Debug.delegate(ba, "button5_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button5_MousePressed rsub = new ResumableSub_Button5_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button5_MousePressed extends BA.ResumableSub {
public ResumableSub_Button5_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=458754;
 //BA.debugLineNum = 458754;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=458755;
 //BA.debugLineNum = 458755;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=458756;
 //BA.debugLineNum = 458756;BA.debugLine="j.Download(UsersRestApiUrl & \"users\") 'gets all u";
_j._download(parent._usersrestapiurl+"users");
RDebugUtils.currentLine=458757;
 //BA.debugLineNum = 458757;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=458758;
 //BA.debugLineNum = 458758;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button5_mousepressed"), (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=458759;
 //BA.debugLineNum = 458759;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=458760;
 //BA.debugLineNum = 458760;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=458762;
 //BA.debugLineNum = 458762;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=458764;
 //BA.debugLineNum = 458764;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _button6_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button6_mousepressed"))
	 {Debug.delegate(ba, "button6_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button6_MousePressed rsub = new ResumableSub_Button6_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button6_MousePressed extends BA.ResumableSub {
public ResumableSub_Button6_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=589826;
 //BA.debugLineNum = 589826;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=589827;
 //BA.debugLineNum = 589827;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=589828;
 //BA.debugLineNum = 589828;BA.debugLine="j.Download(UsersRestApiUrl & \"users?page=2&limit=";
_j._download(parent._usersrestapiurl+"users?page=2&limit=10");
RDebugUtils.currentLine=589829;
 //BA.debugLineNum = 589829;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=589830;
 //BA.debugLineNum = 589830;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button6_mousepressed"), (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=589831;
 //BA.debugLineNum = 589831;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=589832;
 //BA.debugLineNum = 589832;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=589834;
 //BA.debugLineNum = 589834;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=589836;
 //BA.debugLineNum = 589836;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _button7_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(ba, "button7_mousepressed"))
	 {Debug.delegate(ba, "button7_mousepressed", new Object[] {_eventdata}); return;}
ResumableSub_Button7_MousePressed rsub = new ResumableSub_Button7_MousePressed(null,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_Button7_MousePressed extends BA.ResumableSub {
public ResumableSub_Button7_MousePressed(b4j.example.main parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.main parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
anywheresoftware.b4a.objects.collections.Map _data = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{
RDebugUtils.currentModule="main";

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
RDebugUtils.currentLine=917506;
 //BA.debugLineNum = 917506;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=917507;
 //BA.debugLineNum = 917507;BA.debugLine="data.Initialize";
_data.Initialize();
RDebugUtils.currentLine=917513;
 //BA.debugLineNum = 917513;BA.debugLine="data.Put(\"occupation\", \"Web developer and Ui/Ux D";
_data.Put((Object)("occupation"),(Object)("Web developer and Ui/Ux Designer"));
RDebugUtils.currentLine=917515;
 //BA.debugLineNum = 917515;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
RDebugUtils.currentLine=917516;
 //BA.debugLineNum = 917516;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize(ba,"",main.getObject());
RDebugUtils.currentLine=917523;
 //BA.debugLineNum = 917523;BA.debugLine="j.PostString(UsersRestApiUrl & \"user/1\", Map2Http";
_j._poststring(parent._usersrestapiurl+"user/1",_map2httprequeststring(_data)+"&_method=PATCH");
RDebugUtils.currentLine=917525;
 //BA.debugLineNum = 917525;BA.debugLine="SendingRequest";
_sendingrequest();
RDebugUtils.currentLine=917526;
 //BA.debugLineNum = 917526;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, new anywheresoftware.b4a.shell.DebugResumableSub.DelegatableResumableSub(this, "main", "button7_mousepressed"), (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
RDebugUtils.currentLine=917527;
 //BA.debugLineNum = 917527;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
RDebugUtils.currentLine=917528;
 //BA.debugLineNum = 917528;BA.debugLine="LogResponse(j.GetString) ' you can parse json an";
_logresponse(_j._getstring());
 if (true) break;

case 4:
//C
this.state = -1;
;
RDebugUtils.currentLine=917530;
 //BA.debugLineNum = 917530;BA.debugLine="j.Release";
_j._release();
RDebugUtils.currentLine=917532;
 //BA.debugLineNum = 917532;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
}